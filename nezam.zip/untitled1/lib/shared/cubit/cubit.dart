import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nezam/shared/cubit/states.dart';
import 'package:sqflite/sqflite.dart';

class AppCubit extends Cubit<States> {
  AppCubit() : super(AppInitial());

  static AppCubit get(context) => BlocProvider.of(context);

  List<Map> tasks = [];

  void createDataBase()  {
    Database database;

    openDatabase(
      'todo.db',
      version: 1,
      onCreate: (database, version) {
        database.execute('CREATE TABLE tasks (id INTEGER PRIMARY KEY, title TEXT, date TEXT, time TEXT, status TEXT)');
      },
      onOpen: (database) {
        getDataFromDB().then((value) => {
          tasks = value,
          emit(GetDataFromDBState()),
        });
      },
    ).then((value) => {
      database = value,
      emit(CreateDBState()),
    });
  }


  insertToDB({required String title, required String date, required String time, required String desc,})  async {
    var db = await openDatabase('todo.db',version: 1,);
    await db.transaction((txn)  => txn.rawInsert(
        'INSERT INTO tasks (title, date, time, status) VALUES ("$title", "$date", "$time", "new")'
    ).then((value) {
      emit(InsertDBState());
      getDataFromDB().then((value) => {
        tasks = value,
        emit(GetDataFromDBState()),
      });
    }));
  }


  Future<List<Map>> getDataFromDB() async {
    var db = await openDatabase('todo.db',version: 1,onOpen: (database) {
    },);
    tasks = await db.rawQuery('SELECT * FROM tasks');
    return await db.rawQuery('SELECT * FROM tasks');}

  onChangeButtonPressed({required String status, required int id}) async {
    var db = await openDatabase('todo.db',version: 1);    // Update some record
    if(status == 'done'){
      await db.rawUpdate(
          'UPDATE tasks SET status = "new" WHERE id = $id').then((value) =>
      {
        getDataFromDB().then((value) => {tasks = value, emit(GetDataFromDBState())}),

        emit(ChangeButtonPressedState()),
      });
    }else if (status == 'new'){
      await db.rawUpdate(
          'UPDATE tasks SET status = "done" WHERE id = $id').then((value) =>
      {
        getDataFromDB().then((value) => {tasks = value, emit(GetDataFromDBState())}),

        emit(ChangeButtonPressedStatee()),
      });
    }
  }

}