
abstract class States {}

class AppInitial extends States {}

class CreateDBState extends States {}

class InsertDBState extends States {}

class GetDataFromDBState extends States {}

class ChangeButtonPressedState extends States {}

class ChangeButtonPressedStatee extends States {}