import 'package:flutter/material.dart';
import 'package:nezam/shared/cubit/cubit.dart';
import '../constants.dart';

Widget timeDate() => const Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
    Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('July 15, 2022', style: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.bold,
        )),
        SizedBox(height: 5),
        Text('Today'),
      ],
    ),
    SizedBox(height: 20,),
  ],
);


Widget buildTaskItem(Map model, BuildContext context) => Container(
  decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(12.0),
    color: model['status'] == 'new' ? color1 : color2,
  ),
  padding: const EdgeInsets.symmetric(
    horizontal: 15.0,
  ),
  child: Row(
    children: [
      Expanded(child:
      Text(
          '${model['title']}', style: TextStyle(color: model['status'] == 'new' ? color2 : Colors.white)),
      ),
        model['status'] == 'new' ? IconButton(
            onPressed: (){
              AppCubit.get(context).onChangeButtonPressed(status: model['status'], id: model['id']);
            },
            icon: Icon( Icons.check_circle_outline, color: color2)) :
        IconButton(onPressed: (){
          AppCubit.get(context).onChangeButtonPressed(status: model['status'], id: model['id']);
        }, icon:
        const Icon( Icons.check_circle, color: Colors.white)
        ),
    ],
  ),
);