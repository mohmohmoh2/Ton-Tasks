import 'dart:ui';

var color1 = const Color.fromRGBO(67, 120, 219, 0.16);
var color2 =  const Color(0xff405DB5);
