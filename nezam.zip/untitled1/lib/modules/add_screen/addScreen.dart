import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:nezam/shared/cubit/states.dart';
import '../../shared/constants.dart';
import '../../shared/cubit/cubit.dart';

class AddScreen extends StatelessWidget {
  var formKey = GlobalKey<FormState>();
  // Form Controller
  final titleController = TextEditingController();
  final descController = TextEditingController();
  final timeController = TextEditingController();
  final dateController = TextEditingController();

  AddScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  BlocProvider(
      create: (BuildContext context) => AppCubit()..createDataBase() ,
      child: BlocConsumer<AppCubit, States>(
        listener: (BuildContext context, States state) {
          if(state is InsertDBState){
            Navigator.pop(context);
          }
        },
        builder: (BuildContext context, States state) {
          return Scaffold(
              body: SafeArea(
                child: Form(
                  key: formKey,
                  child: Container(
                    padding: const EdgeInsets.all(20.0),
                    color: const Color(0xffE8EEF6),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(height: 30,),
                            Text('مهمة جديدة',
                              style: TextStyle(
                                fontSize: 35.0,
                                fontWeight: FontWeight.bold,
                                color: color2,
                              ),
                            ),
                            const SizedBox(height: 40,),
                            TextFormField(
                              controller: titleController,
                              decoration: const InputDecoration(
                                hintText: 'عنوان المهمه',
                                border: OutlineInputBorder(),
                              ),
                              validator: (value){
                                if(value!.isEmpty){
                                  return 'اكتب عنوان بعد اذنك يا بيه';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20,),
                            TextFormField(
                              controller: dateController,
                              keyboardType: TextInputType.datetime,
                              onTap: (){
                                showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime.now(),
                                  lastDate: DateTime.parse('2044-12-31'),
                                ).then((value) {
                                  value.toString();
                                  dateController.text = DateFormat('yyyy-MM-dd').format(value!);
                                });
                              },
                              decoration: const InputDecoration(
                                hintText: 'التاريخ',
                                border: OutlineInputBorder(),
                                suffixIcon: Icon(Icons.calendar_today_outlined),
                              ),
                              validator: (value){
                                if(value!.isEmpty){
                                  return 'اختار التاريخ يا استاذ';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 10,),
                            TextFormField(
                              controller: timeController,
                              keyboardType: TextInputType.datetime,
                              onTap: (){
                                showTimePicker(
                                  context: context,
                                  initialTime: TimeOfDay.now(),
                                ).then((value) {
                                  timeController.text = value!.format(context).toString();
                                });
                              },

                              decoration: const InputDecoration(
                                hintText: 'الوقت',
                                border: OutlineInputBorder(),
                                suffixIcon: Icon(Icons.watch_later_outlined),

                              ),
                              validator: (value){
                                if(value!.isEmpty){
                                  return 'اكتب الوقت يا استاذ';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20,),
                            TextFormField(
                              controller: descController,
                              decoration: const InputDecoration(
                                hintText: 'وصف المهمه',
                                border: OutlineInputBorder(),
                              ),
                              keyboardType: TextInputType.multiline,
                              textInputAction: TextInputAction.newline,
                              minLines: 5,
                              maxLines: 5,
                              validator: (value){
                                if(value!.isEmpty){
                                  return 'اكتب الوصف يا استاذ';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20,),
                            // const Expanded(child: SizedBox(width: 20,)),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            TextButton(
                              style: TextButton.styleFrom(
                                backgroundColor: color2,
                              ),
                              onPressed: (){
                                if(formKey.currentState!.validate()){
                                  if(descController.text.isEmpty){
                                    descController.text = 'NULLL';
                                  }
                                  AppCubit.get(context).insertToDB(
                                      title: titleController.text,
                                      date: dateController.text,
                                      time: timeController.text,
                                      desc: descController.text
                                  );
                                }
                              },
                              child: const Icon(
                              Icons.chevron_right,
                              color: Colors.white,
                            ),
                            ),
                            const SizedBox(width: 10,),
                            TextButton(

                              style: TextButton.styleFrom(
                                backgroundColor: Colors.red,

                              ),
                              onPressed: (){
                                Navigator.pop(context);
                              },
                              child: const Icon(
                                Icons.close,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              )
          );
        },
      ),
    );
  }
}

