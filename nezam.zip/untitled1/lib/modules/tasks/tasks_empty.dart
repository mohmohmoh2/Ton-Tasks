import 'package:flutter/material.dart';

class TasksEmpty extends StatelessWidget {
  const TasksEmpty({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'لا يوجد مهام',
        style: TextStyle(
          fontSize: 20.0,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
