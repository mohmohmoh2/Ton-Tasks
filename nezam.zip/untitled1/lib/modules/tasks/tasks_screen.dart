import 'package:flutter/material.dart';

class Tasks extends StatefulWidget {
  const Tasks({super.key});

  @override
  State<Tasks> createState() => _TasksState();
}

class _TasksState extends State<Tasks> {
  var color1 = const Color.fromRGBO(67, 120, 219, 0.16);
  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xffE8EEF6),
      padding: const EdgeInsets.all(25.0),
      child: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 5,),
            Container(
              padding: const EdgeInsets.all(5.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: Colors.white,
              ),
              child: const Row(
                children: [
                  Icon(Icons.search),
                  SizedBox(width: 10,),
                  Text('بحث'),
                ],
              ),
            ),
            const SizedBox(height: 20,),
            const Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('July 15, 2022', style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Today'),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20,),
            Column(
              children: [

                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [
                      Expanded(child: Text('اول مهمه تجربه')),
                      IconButton(onPressed: (){},
                          icon: const Icon(Icons.check_circle_outline,color: Color(0xff405DB5)
                          ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [

                      const Expanded(child: Text('تاني مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [
                      Expanded(child: Text('اول مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle_outline,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [

                      const Expanded(child: Text('تاني مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [

                      const Expanded(child: Text('تاني مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [
                      Expanded(child: Text('اول مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle_outline,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [

                      const Expanded(child: Text('تاني مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 15,
                  padding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: color1,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                  ),
                  child: Row(
                    children: [

                      const Expanded(child: Text('تاني مهمه تجربه')),
                      IconButton(onPressed: (){},
                        icon: const Icon(Icons.check_circle,color: Color(0xff405DB5)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 80,),
          ],
        ),
      ),

    );
  }
}
