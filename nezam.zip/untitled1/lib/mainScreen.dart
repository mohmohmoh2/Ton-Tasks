import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nezam/shared/components/components.dart';
import 'package:nezam/shared/cubit/cubit.dart';
import 'package:nezam/shared/cubit/states.dart';
import 'modules/add_screen/addScreen.dart';

class MainScreen extends StatelessWidget {
  var mainColor = const Color(0xffE8EEF6);
  MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => AppCubit()..createDataBase() ,
      child: BlocConsumer<AppCubit, States>(
        listener: (BuildContext context, States state) {
        },
        builder: (BuildContext context, States state) {
          var tasks = AppCubit.get(context).tasks;
          return Scaffold(

          appBar: AppBar(
            centerTitle: true,
              title: const Text('To Do List', textAlign: TextAlign.center,),
              actions: [
                IconButton(
                  icon: const Icon(
                    Icons.menu,
                    color: Colors.black,
                  ),
                  onPressed: () {},
                ),
              ],
              backgroundColor: mainColor,
            ),
            body: tasks.isEmpty
                ? const Center(child: Text('Empty No Tasks'),) : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          timeDate(),
                          const SizedBox(height: 30,),
                          Expanded(
                              child: ListView.separated(
                                shrinkWrap: true,
                                itemBuilder: (context, index) => buildTaskItem(tasks[index], context),
                                separatorBuilder: (context, index) =>
                                const SizedBox(height: 10,),
                                itemCount: tasks.length,
                              ),
                      ),
                    ],
                                  ),
                                ),
                  ],
                ),
            floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
            floatingActionButton: Padding(
              padding: const EdgeInsets.only(bottom: 50.0),
              child: FloatingActionButton(
                shape: const CircleBorder(),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) =>
                     Directionality(
                      textDirection: TextDirection.rtl,
                      child: AddScreen(),
                    )
                    ),
                  );
                },
                backgroundColor: Colors.blue,
                child: const Icon(Icons.add,
                  color: Colors.white,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

}


// class _mainScreenState extends State<mainScreen> {
//   int currentIndex = 0;
//
//   var mainColor = const Color(0xffE8EEF6);
//
//   @override
//   void initState() {
//     super.initState();
//     createDataBase();
//     getDataFromDB().then((value) =>  {tasks = value,});
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('To Do List', textAlign: TextAlign.center,),
//         actions: [
//           IconButton(
//             icon: const Icon(
//               Icons.menu,
//               color: Colors.black,
//             ),
//             onPressed: () {},
//           ),
//         ],
//         backgroundColor: mainColor,
//       ),
//       body: tasks.isEmpty
//           ? const Center(child: Text('Empty No Tasks'))
//           : Padding(
//         padding: const EdgeInsets.all(20.0),
//         child: Container(
//             child: SingleChildScrollView(
//               child: ListView.separated(
//                 shrinkWrap: true,
//                 itemBuilder: (context, index) => buildTaskItem(tasks[index]),
//                 separatorBuilder: (context, index) =>
//                 const SizedBox(height: 10,),
//                 itemCount: tasks.length,
//               ),
//             )
//         ),
//       ),
//       floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
//       floatingActionButton: Padding(
//         padding: const EdgeInsets.only(bottom: 50.0),
//         child: FloatingActionButton(
//           shape: const CircleBorder(),
//           onPressed: () {
//             Navigator.push(
//               context,
//               MaterialPageRoute(builder: (context) =>
//               const Directionality(
//                 textDirection: TextDirection.rtl,
//                 child: AddScreen(),
//               )
//               ),
//             );
//           },
//           backgroundColor: Colors.blue,
//           child: const Icon(Icons.add,
//             color: Colors.white,
//           ),
//         ),
//       ),
//     );
//   }
//
// }