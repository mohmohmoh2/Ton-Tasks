package com.nezam.tasks.nezam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
